
export interface Movie{
    id:number;
    title:String;
    boxOffice:number;
    active:String;
    dateOfLaunch:String;
    genre:String;
    hasTeaser:String
}