
export interface Favorite{
    id:number;
    title:String;
    genre:String;
}